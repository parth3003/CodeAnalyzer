Explain about bmk.json file

delayBmk is for filter out all delay more the specified seconds.

varPattern is for variable name pattern, datatypeDict.json define prefix. 
1:prefix + Japanese or EnglishCamelCase
2:prefix + CamelCase
0:camelCase

argPattern is for argument name pattern.
1:arg + prefix + Japanese or EnglishCamelCase
2:arg + prefix + CamelCase etc.
3:arg + CamelCase
4:camelCase
